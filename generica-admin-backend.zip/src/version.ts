export const APP_VERSION = '2.0.0';
