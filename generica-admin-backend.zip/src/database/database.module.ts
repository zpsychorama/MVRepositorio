import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Countries } from 'core/countries/country.entity';
import { Companies } from 'core/companies/company.entity';
import { Responsible } from 'core/responsible_companies/responsible-companies.entity';
import { State } from 'core/states/states.entity';
import { Roles } from 'core/roles/roles.entity';
import { Customers } from 'core/customers/customer.entity';
import { User } from 'core/user_companies/user-companies.entity';
import {
    DB_HOST,
    DB_PORT,
    DB_USERNAME,
    DB_PASSWORD,
    DB_DATABASE,
} from 'common/constants/setup.constants';

@Module({
    imports: [
        TypeOrmModule.forRoot({
            type: 'mysql',
            host: DB_HOST,
            port: DB_PORT,
            username: DB_USERNAME,
            password: DB_PASSWORD,
            database: DB_DATABASE,
            entities: [
                Countries,
                State,
                Companies,
                Responsible,
                Roles,
                Customers,
                User,
            ],
            synchronize: false,
        }),
    ],
})
export class AppModule {}