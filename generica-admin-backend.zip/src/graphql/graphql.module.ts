import { Module } from '@nestjs/common';
import { GraphQLModule } from '@nestjs/graphql';
import { GqlContext } from './graphql.guard';

@Module({
  imports: [
    GraphQLModule.forRoot({
      autoSchemaFile: 'schema.gql',
      context: ({
        req,
      }: {
        req: { headers: Record<string, string> };
      }): GqlContext => ({ request: req }),
    }),
  ],
})
export class GraphqlModule {}
