/** ------------------------------------------------------
 * THIS FILE WAS AUTOMATICALLY GENERATED (DO NOT MODIFY)
 * -------------------------------------------------------
 */

/* tslint:disable */
/* eslint-disable */
export enum Flag {
  E = 'E',
  N = 'N',
  P = 'P',
  D = 'D',
  A = 'A',
  PA = 'PA',
  PAP = 'PAP',
  AP = 'AP',
  FPPA = 'FPPA',
  FPA = 'FPA',
  ASN = 'ASN',
}

export class UpdateOrderInput {
  flag?: Flag;
}

export abstract class IQuery {
  abstract getOrders(): Order[] | Promise<Order[]>;

  abstract order(id: string): Order | Promise<Order>;
}

export abstract class IMutation {
  abstract changeFlag(
    id: string,
    updateOrderInput?: UpdateOrderInput,
  ): Order | Promise<Order>;
}

export abstract class ISubscription {
  abstract orderUpdated(): Order | Promise<Order>;
}

export class Order {
  id?: number;
  flag?: Flag;
}
