export const MERCHANT_ID = '508029';
export const API_KEY = '4Vj8eK4rloUd272L48hsrarnUA';
export const API_LOGIN = 'pRRXKOl8ikMmt9u';
export const API_URL_CONFIRM = 'http://localhost:3000/payments/pse/confirm';
export const API_URL_RESPONSE = 'http://localhost:3000/payments/pse/response';
export const ACCOUNT_ID = {
  COLOMBIA: '512321',
  ARGENTINA: '512322',
  CHILE: '512325',
  MEXICO: '512324',
  PANAMA: '512326',
  PERU: '512323',
  BRASIL: '512327',
};
export const PAYMENTS_URL =
  'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
export const REPORTS_URL =
  'https://sandbox.api.payulatam.com/reports-api/4.0/service.cgi';
export const PAY_STATES = {
  NEW: 'NEW',
  PENDING: 'PENDING',
  WAITING_FOR_CONFIRMATION: 'WAITING_FOR_CONFIRMATION',
  COMPLETED: 'COMPLETED',
  CANCELED: 'CANCELED',
  REJECTED: 'REJECTED',
};
