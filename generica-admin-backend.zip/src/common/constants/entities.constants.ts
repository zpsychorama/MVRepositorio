export const DELIVERY_ORDERS = 'delivery_orders';
export const DELIVERY_ORDERS_DETAIL = 'delivery_order_details';
export const GROUPS = 'groups';
export const SUB_GROUPS = 'sub_groups';
export const CUSTOMERS_ADDRESSES = 'customer_addresses';
