export const JWT_SECRET = 'mv_administracion_v2';
export const JWT_EXPIRE = '60s';

export const TWILIO = {
  ACCOUNT_SID: 'ACae355046cc93adf352a84e167797660f',
  AUTH_TOKEN: '3ac034a453b783a20fc7613422c730df',
  PHONE_NUMBER: '+12152740230',
};

export const administracion_movilventas_v2 = 'PUPO_2020';

/** PRODUCTION */
// const MYSQL_ADDON_HOST = '3.234.176.108';
// const MYSQL_ADDON_DB = 'movilventas_sales_generic_pro';
// const MYSQL_ADDON_USER = 'mvusergeneric';
// const MYSQL_ADDON_PORT = 3306;
// const MYSQL_ADDON_PASSWORD = 'mV7F=6mg@%';

/** DEVELOPMENT */
const MYSQL_ADDON_HOST = '68.66.194.199';
const MYSQL_ADDON_DB = 'tav1985_generic_sales_test';
const MYSQL_ADDON_USER = 'tav1985';
const MYSQL_ADDON_PORT = 3306;
const MYSQL_ADDON_PASSWORD = 'xXf0UL$mM@@D';

/** LOCAL */
// const MYSQL_ADDON_HOST = 'localhost';
// const MYSQL_ADDON_DB = 'movilventas_sales_generic_pro';
// const MYSQL_ADDON_USER = 'mvusergeneric';
// const MYSQL_ADDON_PORT = 3306;
// const MYSQL_ADDON_PASSWORD = 'mV7F=6mg@%';

export const DB_HOST = MYSQL_ADDON_HOST || 'localhost';
export const DB_PORT = MYSQL_ADDON_PORT || 3306;
export const DB_USERNAME = MYSQL_ADDON_USER || 'root';
export const DB_PASSWORD = MYSQL_ADDON_PASSWORD || 'root';
export const DB_DATABASE = MYSQL_ADDON_DB || 'test';
