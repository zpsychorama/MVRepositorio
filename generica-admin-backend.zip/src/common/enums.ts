export enum CONDITIONAL {
  YES = 'YES',
  NO = 'NO',
  UNKNOWN = 'UNKNOWN',
}

export enum DELIVERY_ORDERS_FLAG {
  E = 'E',
  N = 'N',
  P = 'P',
  D = 'D',
  A = 'A',
  PA = 'PA',
  PAP = 'PAP',
  AP = 'AP',
  FPPA = 'FPPA',
  FPA = 'FPA',
  ASN = 'ASN',
}

export enum DELIVERY_ORDERS_STATUS {
  S = 'S',
  N = 'N',
}

export enum DELIVERY_ORDERS_TYPE_LOAD {
  DL = 'DL',
  DDL = 'DLL',
  UNKNOWN = 'UNKNOWN',
}

export enum DELIVERY_ORDERS_DETAIL_STATUS {
  D = 'D',
  N = 'N',
  UNKNOWN = 'UNKNOWN',
}
