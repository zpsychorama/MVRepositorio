import { Injectable, Scope } from '@nestjs/common';
import { TWILIO } from 'common/constants/setup.constants';

const twilio = require('twilio')(TWILIO.ACCOUNT_SID, TWILIO.AUTH_TOKEN);

@Injectable({ scope: Scope.REQUEST })
export class TwilioService {
  twilioInstance = twilio;
  public checkPhone(phone: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.twilioInstance.lookups
        .phoneNumbers(phone)
        .fetch({ type: ['carrier'] })
        .then((data) => resolve(data.carrier))
        .catch((error) => reject(error));
    });
  }

  public sendCode(phone: string, code: number): Promise<any> {
    return new Promise((resolve, reject) => {
      this.twilioInstance.messages
        .create({
          body: `Pupo code is: ${code}`,
          from: TWILIO.PHONE_NUMBER,
          to: phone,
        })
        .then((message) => resolve(message))
        .catch((error) => reject(error));
    });
  }
}
