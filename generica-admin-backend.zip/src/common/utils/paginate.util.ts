export const paginate = ({ items, page, limit }) =>
  items.slice((page - 1) * limit, page * limit);

export const newPaginate = ({ items, page, limit }) => {
  console.log(page);
  return items.slice((page - 1) * limit, page * limit);
};
