import * as _ from 'lodash';

export const merge = (firstArray, secondArray, key) =>
  _.map(firstArray, (obj) =>
    _.assign(
      obj,
      _.find(secondArray, {
        [key]: obj[key],
      }),
    ),
  );
