import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  NestjsQueryGraphQLModule,
  PagingStrategies,
} from '@nestjs-query/query-graphql';
import { NestjsQueryTypeOrmModule } from '@nestjs-query/query-typeorm';
import { Responsible } from 'core/responsible_companies/responsible-companies.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Responsible]),
    NestjsQueryGraphQLModule.forFeature({
      imports: [NestjsQueryTypeOrmModule.forFeature([Responsible])],
      resolvers: [
        {
          DTOClass: Responsible,
          EntityClass: Responsible,
          pagingStrategy: PagingStrategies.OFFSET,
          enableSubscriptions: true,
        },
      ],
    }),
  ],
})
export class ResponsibleModule {}
