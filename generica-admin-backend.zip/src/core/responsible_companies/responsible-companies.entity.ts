import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { FilterableField, Relation } from '@nestjs-query/query-graphql';
import { ObjectType, ID, Field, InputType } from '@nestjs/graphql';
import { Companies } from 'core/companies/company.entity';

@InputType('ResponsiblesInput')
@Relation('company', () => Companies, { disableRemove: true })
@ObjectType('Responsible')
@Entity({ name: 'company_responsibles' })
export class Responsible {
  @FilterableField(() => ID)
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @FilterableField()
  @Column({ type: 'char', length: 45 })
  name: string;

  @FilterableField()
  @Column({ type: 'varchar', length: 45 })
  phone: string;

  @FilterableField()
  @Column({ type: 'varchar', length: 45 })
  email: string;

  @FilterableField()
  @Column({ type: 'varchar', length: 45 })
  position: string;

  @FilterableField()
  @Column('boolean')
  is_active: boolean;

  @Field(() => ID)
  @ManyToOne(() => Companies, (company) => company.responsibles)
  @JoinColumn({ name: 'company_id' })
  company: Companies;
}
