import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  NestjsQueryGraphQLModule,
  PagingStrategies,
} from '@nestjs-query/query-graphql';
import { NestjsQueryTypeOrmModule } from '@nestjs-query/query-typeorm';
import { Customers } from 'core/customers/customer.entity';
import { CustomersService } from 'core/customers/customer.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([Customers]),
    NestjsQueryGraphQLModule.forFeature({
      imports: [NestjsQueryTypeOrmModule.forFeature([Customers])],
      resolvers: [
        {
          DTOClass: Customers,
          EntityClass: Customers,
          pagingStrategy: PagingStrategies.OFFSET,
        },
      ],
    }),
  ],
  providers: [CustomersService],
  exports: [CustomersService],
})
export class CustomersModule {}
