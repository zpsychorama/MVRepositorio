import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { encrypt } from 'common/utils/crypto.util';
import { Customers } from 'core/customers/customer.entity';

@Injectable()
export class CustomersService {
  constructor(
    @InjectRepository(Customers)
    private readonly customersRepository: Repository<Customers>,
  ) {}

  async findByPhone(phone: string): Promise<Customers> {
    return this.customersRepository.findOne({ phone });
  }

  async createToken(phone: string, code: string): Promise<Customers> {
    const customerFounded = await this.customersRepository.findOne({ phone });
    if (customerFounded) {
      customerFounded.token = encrypt(code);
      const costumerSaved = await this.customersRepository.save(
        customerFounded,
      );
      return costumerSaved;
    }
    return null;
  }
}
