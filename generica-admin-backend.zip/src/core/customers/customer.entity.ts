import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { FilterableField } from '@nestjs-query/query-graphql';
import { ObjectType, ID, Field, GraphQLISODateTime } from '@nestjs/graphql';
import { CustomerStatus } from 'core/customers/customers.enum';

@ObjectType('Customers')
@Entity('customers')
export class Customers {
  @FilterableField(() => ID)
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @FilterableField()
  @Column({
    type: 'char',
    length: 36,
  })
  unique_code: string;

  @Column({
    type: 'varchar',
    length: 50,
  })
  token: string;

  @FilterableField()
  @Column({
    type: 'int',
    width: 10,
  })
  identification_type_id: number;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 30,
  })
  identification: string;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 100,
  })
  first_name: string;

  @FilterableField({ nullable: true })
  @Column({
    type: 'varchar',
    length: 50,
  })
  last_name: string;

  @FilterableField({ nullable: true })
  @Column({
    type: 'varchar',
    length: 20,
    nullable: true,
  })
  username: string;

  @FilterableField({ nullable: true })
  @Column({
    type: 'varchar',
    length: 11,
    nullable: true,
  })
  password: string;

  @FilterableField({ nullable: true })
  @Column({
    type: 'bigint',
    nullable: true,
  })
  customer_potential_id: number;

  @FilterableField()
  @Column({ type: 'varchar', length: 50 })
  buy_contact: string;

  @FilterableField({ nullable: true })
  @Column({
    type: 'int',
    width: 20,
    nullable: true,
  })
  customer_type_id: number;

  @FilterableField({ nullable: true })
  @Column({
    type: 'char',
    length: 36,
    nullable: true,
  })
  city_code: string;

  @FilterableField()
  @Column({
    type: 'decimal',
    precision: 28,
    scale: 3,
  })
  quota: number;

  @FilterableField()
  @Column({
    type: 'decimal',
    precision: 13,
    scale: 2,
  })
  credit: number;

  @FilterableField({ nullable: true })
  @Column({
    type: 'varchar',
    length: 70,
    nullable: true,
  })
  dispatch_day: string;

  @FilterableField({ nullable: true })
  @Column({
    type: 'varchar',
    length: 300,
    nullable: true,
  })
  distributors: string;

  @FilterableField({ nullable: true })
  @Column({
    type: 'varchar',
    length: 20,
    nullable: true,
  })
  department: string;

  @FilterableField({ nullable: true })
  @Column({
    type: 'varchar',
    length: 50,
    nullable: true,
  })
  city: string;

  @FilterableField()
  @Column('boolean')
  is_active: boolean;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 32,
    nullable: true,
  })
  api_key: string;

  @FilterableField({ nullable: true })
  @Column({
    type: 'datetime',
    nullable: true,
  })
  last_sync: Date;

  @FilterableField()
  @Column({
    type: 'enum',
    name: 'new_customer_status',
    enum: CustomerStatus,
    default: CustomerStatus.S,
  })
  new_customer_status: CustomerStatus;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 500,
    nullable: true,
  })
  sinc_response: string;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 500,
    nullable: true,
  })
  payment_conditions: string;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 50,
  })
  image: string;

  @FilterableField({ nullable: true })
  @Column({
    type: 'varchar',
    length: 50,
    nullable: true,
  })
  logo: string;

  @FilterableField()
  @Column({
    type: 'int',
    width: 11,
  })
  idr: number;

  @FilterableField({ nullable: true })
  @Column({
    type: 'varchar',
    length: 20,
    nullable: true,
  })
  phone: string;

  @Field(() => GraphQLISODateTime)
  @CreateDateColumn()
  created: Date;

  @Field(() => GraphQLISODateTime)
  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)',
  })
  modified: Date;
}
