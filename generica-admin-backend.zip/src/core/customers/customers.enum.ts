export enum CustomerStatus {
  S = 'S',
  N = 'N',
  E = 'E',
}
