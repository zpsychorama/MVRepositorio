import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  NestjsQueryGraphQLModule,
  PagingStrategies,
} from '@nestjs-query/query-graphql';
import { NestjsQueryTypeOrmModule } from '@nestjs-query/query-typeorm';
import { Countries } from 'core/countries/country.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Countries]),
    NestjsQueryGraphQLModule.forFeature({
      imports: [NestjsQueryTypeOrmModule.forFeature([Countries])],
      resolvers: [
        {
          DTOClass: Countries,
          EntityClass: Countries,
          pagingStrategy: PagingStrategies.OFFSET,
        },
      ],
    }),
  ],
})
export class CountryModule {}
