import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { FilterableField } from '@nestjs-query/query-graphql';
import { ObjectType, ID } from '@nestjs/graphql';
@ObjectType('Countries')
@Entity({ name: 'countries' })
export class Countries {
  @FilterableField(() => ID)
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 100,
  })
  name: string;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 100,
  })
  capital: string;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 255,
  })
  region: string;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 255,
  })
  subregion: string;
}
