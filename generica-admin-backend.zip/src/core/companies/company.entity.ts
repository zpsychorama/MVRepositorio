import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { FilterableField, Connection } from '@nestjs-query/query-graphql';
import { ObjectType, ID } from '@nestjs/graphql';
import { Responsible } from 'core/responsible_companies/responsible-companies.entity';

@Connection('responsibles', () => Responsible, { disableRemove: true })
@ObjectType('Companies')
@Entity({ name: 'companies' })
export class Companies {
  @FilterableField(() => ID)
  @PrimaryGeneratedColumn({ type: 'bigint' })
  idr: number;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 100,
  })
  name: string;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 50,
  })
  timezone: string;

  @FilterableField()
  @Column({
    type: 'varchar',
    width: 15,
  })
  phone: string;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 45,
  })
  address: string;

  @FilterableField()
  @Column('boolean')
  isActivate: boolean;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 30,
  })
  country: string;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 45,
  })
  city: string;

  @OneToMany(() => Responsible, (responsible) => responsible.company)
  responsibles: Responsible[];
}
