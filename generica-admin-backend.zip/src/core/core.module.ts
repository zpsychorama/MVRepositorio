import { Module } from '@nestjs/common';
import { CountryModule } from 'core/countries/countries.module';
import { CompanyModule } from 'core/companies/company.module';
import { ResponsibleModule } from './responsible_companies/responsible-companies.modules';
import { StatesModule } from 'core/states/states-modules';
import { RolesModule } from 'core/roles/roles.modules';
import { CustomersModule } from 'core/customers/customer.module';
import { UserModule } from 'core/user_companies/user-companies.modules';
@Module({
  imports: [
    CountryModule,
    CompanyModule,
    ResponsibleModule,
    StatesModule,
    RolesModule,
    CustomersModule,
    UserModule,
  ],
})
export class CoreModule {}
