import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  NestjsQueryGraphQLModule,
  PagingStrategies,
} from '@nestjs-query/query-graphql';
import { NestjsQueryTypeOrmModule } from '@nestjs-query/query-typeorm';
import { State } from 'core/states/states.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([State]),
    NestjsQueryGraphQLModule.forFeature({
      imports: [NestjsQueryTypeOrmModule.forFeature([State])],
      resolvers: [
        {
          DTOClass: State,
          EntityClass: State,
          pagingStrategy: PagingStrategies.OFFSET,
          enableSubscriptions: true,
        },
      ],
    }),
  ],
})
export class StatesModule {}