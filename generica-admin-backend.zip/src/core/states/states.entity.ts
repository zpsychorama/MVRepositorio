import {
    Column,
    CreateDateColumn,
    Entity,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
    ManyToOne,
    OneToMany,
    JoinColumn,
  } from 'typeorm';
  import {
    FilterableField,
    Relation,
    Connection,
  } from '@nestjs-query/query-graphql';
  import { ObjectType, ID, GraphQLISODateTime } from '@nestjs/graphql';
  
  
  @ObjectType('States')
  @Entity({ name: 'states' })
  export class State {
    @FilterableField(() => ID)
    @PrimaryGeneratedColumn({ type: 'bigint' })
    id: number;
  
    @FilterableField()
    @Column({ type: 'varchar', length: 255 })
    name: string;
  
    @FilterableField()
    @Column({ type: 'int', width: 8 })
    country_id: number;
  
  }