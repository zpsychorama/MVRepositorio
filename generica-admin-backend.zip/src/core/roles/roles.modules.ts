import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  NestjsQueryGraphQLModule,
  PagingStrategies,
} from '@nestjs-query/query-graphql';
import { NestjsQueryTypeOrmModule } from '@nestjs-query/query-typeorm';
import {Roles} from 'core/roles/roles.entity'

@Module({
  imports: [
    TypeOrmModule.forFeature([Roles]),
    NestjsQueryGraphQLModule.forFeature({
      imports: [NestjsQueryTypeOrmModule.forFeature([Roles])],
      resolvers: [
        {
          DTOClass: Roles,
          EntityClass: Roles,
          pagingStrategy: PagingStrategies.OFFSET,
          enableSubscriptions: true,
        },
      ],
    }),
  ],
})
export class RolesModule {}
