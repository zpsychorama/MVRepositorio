import { Entity, PrimaryGeneratedColumn, Column, OneToMany, ManyToOne,
  JoinColumn } from 'typeorm';
import { FilterableField, Connection, Relation } from '@nestjs-query/query-graphql';
import { ObjectType, ID } from '@nestjs/graphql';
import {User} from 'core/user_companies/user-companies.entity'

@ObjectType('Roles')
@Relation('user', () => User, { disableRemove: true })
@Entity({ name: 'roles' })
export class Roles {
  @FilterableField(() => ID)
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 50,
  })
  name: string;

  @FilterableField()
  @Column({
    type: 'varchar',
    length: 500,
  })
  Description: string;

  @ManyToOne(() => User, (user) => user.role)
  @JoinColumn({ name: 'id' })
  user: User;

}
