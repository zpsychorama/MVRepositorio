import {
    Column,
    CreateDateColumn,
    Entity,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
    ManyToOne,
    OneToMany,
    JoinColumn,
  } from 'typeorm';
  import {
    FilterableField,
    Relation,
    Connection,
  } from '@nestjs-query/query-graphql';
  import { ObjectType, ID, GraphQLISODateTime } from '@nestjs/graphql';
  import { Roles } from 'core/roles/roles.entity'
  
  @Connection('roles', () => Roles, { disableRemove: true })
  @ObjectType('User')
  @Entity({ name: 'users' })
  export class User {
    @FilterableField(() => ID)
    @PrimaryGeneratedColumn({ type: 'bigint' })
    id: number;

    @FilterableField()
    @Column({ type: 'varchar', length: 36 })
    identification: string;

    @FilterableField()
    @Column({ type: 'char', length: 50 })
    first_name: string;

    @FilterableField()
    @Column({ type: 'char', length: 50 })
    last_name: string;

  
    @FilterableField()
    @Column({ type: 'char', length: 20 })
    username: string;

    @FilterableField()
    @Column({ type: 'char', length: 11 })
    password: string;
  
    @FilterableField()
    @Column({ type: 'varchar', length: 20 })
    phone: string;
  
    @FilterableField()
    @Column({ type: 'varchar', length: 100 })
    email: string;

    @FilterableField()
    @Column({ type: 'int', width:10 })
    role_id: number;

    @OneToMany(() => Roles, (role) => role.user)
    role: Roles[];

   
  
  
  
  }