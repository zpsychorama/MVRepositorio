import { Module } from '@nestjs/common';
import { CoreModule } from './core/core.module';
import { DatabaseModule } from './database/database.module';
import { GraphqlModule } from './graphql/graphql.module';
@Module({
  imports: [CoreModule, DatabaseModule, GraphqlModule],
})
export class AppModule {}
