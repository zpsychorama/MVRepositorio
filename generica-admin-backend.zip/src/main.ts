import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { AppModule } from 'app.module';
import { MARKETPLACE_TAG } from 'common/constants/swagger.constants';
import { APP_VERSION } from 'version';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const options = new DocumentBuilder()
    .setTitle('Movilventas App administrativa')
    .setDescription('Descripcón servicios administración')
    .setVersion(`v${APP_VERSION}`)
    .addTag(MARKETPLACE_TAG)
    .addBearerAuth()
    .build();
  const document = SwaggerModule.createDocument(app, options);

  SwaggerModule.setup('api', app, document);
  await app.listen(3001);
  console.log(`Application is running on: ${await app.getUrl()}`);
}

bootstrap();
