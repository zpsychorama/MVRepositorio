# Requirements

## 1. Servicio (query) para consultar banners.

### Generico
```graphql
  query {
    products(filter: { id: { eq: 5933 } }) {
      name
      productToImages {
        edges {
          node {
            main
            imageType
            created
            images {
              name
              description
              url
              size
              is_active
            }
          }
        }
      }
    }
  }
```

### Banners
```graphql
  query {
    products(filter: { id: { eq: 5933 } }) {
      name
      productToImages(filter: { imageType: { eq: "BANNER" } }) {
        edges {
          node {
            main
            imageType
            created
            images {
              name
              description
              url
              size
              is_active
            }
          }
        }
      }
    }
  }
```

## 2. Servicio (query) para el filtrado de las companies de acuerdo a los filtros solicitados por alejandro.
```graphql
  query {
    companies(filter: { is_marketplace: { is: true } }) {
      name
      timezone
      logo
      banner
      urlweb
      accounting
      collection
      advances
      consignments
      messages
      customer_zone_type
      price_list_type_id
      visits
      transporters
      trans_assign
      promotions
      web_track_precision
      load_orders_to_deliveries
      delivery_date
      newness_user
      sales_stats
      order_email_total
      order_email
      main_menu
      simple_survey
      simple_survey
      customer_geolocation
      customer_dispatch_day
      customer_type
      potential
    }
  }
```
## 3. Ejemplo data post, para los procesos de pago con las diferentes plataformas.
R/ El endpoint de pagos describe el objeto del mensaje

## 4. Servicio (query) de imagenes con la relacion para companies, catalogs, products.
```
query {
  products(filter: { id: { eq: 5933 } }) {
    name
    product_prices {
      edges {
        node {
          id
          product_reference
          price
          discount
          catalog_id {
            name
          }
        }
      }
    }
    productToImages {
      edges {
        node {
          main
          imageType
          created
          images {
            name
            description
            url
            size
            is_active
          }
        }
      }
    }
  }
}
```
## 5. Carga de datos mas reales para tener contenido mas similar a lo que se espera en produccion.
  R/ Los datos existentes son una copia de la base de datos de producción.
## 6. Habilitar Ranking para los products.
### Ranking query
```
query {
  products {
    id
    reference
    ranking
    stock
  }
}
```

## 7. Servicio (query) para el historico de ordenes.
### Historico de Ordenes por customerId
```
query {
  deliveryOrders(filter: { customer_id: { eq: 3267 } }) {
    id
    ship_id
    invoice
    flag
  }
}
```
### Historico de ordernes para todos los customer
```
query {
  deliveryOrders {
    id
    ship_id
    invoice
    flag
  }
}
```

## 8. Query ejemplo de la mutacion para la orden de como se crean y estados que se manejan.
Estados que se manejan iternamente las ordenes:
'E','N','P','D','A','PA','PAP','AP','FPPA','FPA','ASN', 'EF'

```
mutation {
  createOneDeliveryOrders(
    input: {
      deliveryOrders: {
        pedido: "Test",
        address_seq_num: 9,
        customer_id : 1,
        zone_name: "test",
        invoice: "ORDER-MV-7458",
        flag: "EF",
        status_efectivo: "1"
      }
    }
  ) {
    id
    invoice
    
  }
}

## 9. Imagenes de los catalogos 

```graphql
  query {
    catalogs(filter: { id: { eq: 64 } }) {
      name
      catalogToImages {
        edges {
          node {
            images {
              url
            }
            main
          }
        }
      }
    }
  }
```

## 10. Imagenes de las compañias

```graphql

```
<<<<<<< HEAD
=======



## 11 Creacion de clientes

mutation {
  createOneCustomers(input: { 
    customers: { 
      first_name: "Ricardo",
  		last_name: "Cardona",
      phone: "3219294015",
      identification: "1088026680",
      buy_contact: "ricardocardona13@gmail.com",
      quota: 200000,
      identification_type_id: 4,
      customer_potential_id: 1,
      credit: 0,
      dispatch_day: "", 
  		distributors: "",
      department: "",
  		new_customer_status: "S",
  		image: "nodisponible.jpg",
  		idr: 1,
    } 
  }) {
    id
    phone
    identification
    first_name
    last_name
    idr
  }
}
>>>>>>> d9470b830d3703cf0b829406aa2fa98e7559e9ea
