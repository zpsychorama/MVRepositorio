# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [2.0.0](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/compare/v1.7.0...v2.0.0) (2020-11-27)


### Bug Fixes

* adjust the structure to the genetics project ([d058e77](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/d058e77c695f4dfe5c70cd12d596c6e4a267bf24))

## [1.7.0](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/compare/v1.6.0...v1.7.0) (2020-11-13)

### Features
* Update critial dependencies

## [1.6.0](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/compare/v1.5.1...v1.6.0) (2020-09-28)


### Features

* Cash payment statuses are added ([dd8268f](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/dd8268f56a0f754d302009bb51a9b9b851c82750))

### [1.5.1](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/compare/v1.5.0...v1.5.1) (2020-09-17)


### Features

* correction fields null delivery orders and error in invoice field ([11f8251](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/11f8251dac1f694019511cc0494f4e961e6853a0))

## [1.5.0](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/compare/v1.4.0...v1.5.0) (2020-09-17)


### Features

* Group and subgroup relationships with customers ([abfd76c](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/abfd76c5b7657841123b9492af783cae35321257))

## [1.4.0](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/compare/v1.3.0...v1.4.0) (2020-09-08)


### Features

* add triggers for image validation when adding or removing ([d9470b8](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/d9470b830d3703cf0b829406aa2fa98e7559e9ea))
* requirements, delivery-order-detail ([5ed0a85](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/5ed0a85bb151855fdfcd05b8210296eb512f9b7c))

## [1.3.0](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/compare/v1.2.0...v1.3.0) (2020-08-21)


### Features

* add company and catalog's image and fix delivery orders ([babc696](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/babc69679505532cc1a24d27dd884a39f270c90d))

## [1.2.0](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/compare/v1.1.2...v1.2.0) (2020-08-19)


### Features

* add images of products and is_marketplace query ([ba5fc5e](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/ba5fc5e2488ee5ae8e0ee55b598aa2f6c5054514))
* add new flow products and images, bugfix other features ([44e21ee](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/44e21ee0d8ab1960fc1d92a7348cc4828d6d38c8))


### Bug Fixes

* bugfix payu service and catalogs service ([6f5fa9e](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/6f5fa9e177c3de1566861f0bad1d78983e134285))
* bugfix product images ([7d7d8de](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/7d7d8de2fcfe45813543b54646a0b469e48487e7))

### [1.1.2](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/compare/v1.1.1...v1.1.2) (2020-07-24)


### Bug Fixes

* bugfix all queries ([7a6b092](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/7a6b0921a7fe9d17a58ca0b553deb641cde523fb))
* bugfix customers and products ([d53bf5d](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/d53bf5de61d3d803a238a516e76378fc41f27654))
* bugfix images ([e5bca71](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/e5bca71ddefb2e81be4b2010f20e2cad912cd448))
* bugfix images on products ([1edfa99](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/1edfa998c9a0e9092c46bfbe7258f37f7f7a8ba3))
* bugfix nullable fields on customers ([c4600fb](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/c4600fb4b9fa23d65e78887e06bc82cd7a03e1f3))
* bugfix scripts ([a6c72cc](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/a6c72cc014205bd2e72f4f80e2b91159b0e331f7))

### [1.1.1](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/compare/v1.1.0...v1.1.1) (2020-07-22)


### Features

* add countries - cities module ([03a0bec](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/03a0beca537a8c939c4674d96738e17248d923f9))
* add filter by country and city ([4eb167d](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/4eb167d8559e8d70c13ee5ff2bc5f612c999650b))
* add integration subscription services, refactor and clean code ([f54b168](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/f54b168c6bb5cecd15797741be833cd137c75523))
* add new auth flow ([e3974e0](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/e3974e0bd6bc119cdad1a663e7643e30aa1d1135))
* add observer for delivery orders ([4db067d](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/4db067d83a1c7de235a0eb829f077f0a32def6a4))
* add old flow ([4e70e68](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/4e70e68be7c25adb661e4c436c7c33733f33300a))
* add orders query ([c531e42](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/c531e42ac52bae1d5db6b9b94d3bc811005ff5cc))
* add payment module and fix auth module ([980058a](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/980058aeaa05964502a17719dc84c072fe1be29a))
* add promotions query ([921f5e5](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/921f5e51cf46721691176f7661869ac4c10cd6e0))


### Bug Fixes

* bugfix auth flow ([f6639a3](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/f6639a38d60cde8633825a7a2a71c56e32f62b7e))
* bugfix confirm phone flow ([3530b37](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/3530b379f5d1cd295c94b370daa076166dfe9820))
* bugfix for modules commented by mistake ([2bae8fa](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/2bae8fa2b593bc5fe9eed8e0de523cbcfcc61418))
* bugfix product prices ([798ba60](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/798ba60d3d193ca973acd58d68ad1adba84ee081))

## 1.1.0 (2020-06-16)


### Features

* add authentication to all endpoints ([573091a](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/573091a78cd569e45770e01119c10e5e9f2c35da))
* add companies endpoint ([b50fb80](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/b50fb80edc2c9a7a62376b72e0ad473cb1e30071))
* add configuration for app and images endpoints ([6016269](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/601626935b1b977ceba0d547ca8ec893a347c6b9))
* add initial project ([40b379d](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/40b379d0f82df7c1b30d88671a06f1c270114ebc))
* add local constants ([94eccfa](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/94eccfa2f4032d0d896d59c9613eb4ec3cdda127))
* add zones, products and catalogs endpoints ([ec31551](https://bitbucket.org/movilventas/generic-marketplace-api-nestjs/commit/ec315515621812f5c1651fad28c37442b1eefaa4))
