-- TRIGGERS TABLE PRODUCT_IMAGES


DROP TRIGGER IF EXISTS `t_delete_products_images`;
DELIMITER //
CREATE  TRIGGER `t_delete_products_images` AFTER DELETE ON `product_images`
 FOR EACH ROW BEGIN
 	IF NOT EXISTS(SELECT * FROM catalog_images WHERE image_id = OLD.image_id ) THEN
 		IF NOT EXISTS(SELECT * FROM company_images WHERE image_id = OLD.image_id ) THEN
		  UPDATE images set has_relation = 0 WHERE id = OLD.image_id;
	 	END IF;
 	END IF;		
  END
//
DELIMITER ;


DROP TRIGGER IF EXISTS `t_insert_products_images`;
DELIMITER //
CREATE  TRIGGER `t_insert_products_images` BEFORE INSERT ON `product_images`
 FOR EACH ROW BEGIN

 	UPDATE images set has_relation = 1 WHERE id = NEW.image_id;
  END
//
DELIMITER ;



-- TRIGGERS TABLE CATALOG_IMAGES

DROP TRIGGER IF EXISTS `t_delete_catalog_images`;
DELIMITER //
CREATE  TRIGGER `t_delete_catalog_images` AFTER DELETE ON `catalog_images`
 FOR EACH ROW BEGIN
 	IF NOT EXISTS(SELECT * FROM product_images WHERE image_id = OLD.image_id ) THEN
 		IF NOT EXISTS(SELECT * FROM company_images WHERE image_id = OLD.image_id ) THEN
		  UPDATE images set has_relation = 0 WHERE id = OLD.image_id;
	 	END IF;
 	END IF;		
  END
//
DELIMITER ;


DROP TRIGGER IF EXISTS `t_insert_catalog_images`;
DELIMITER //
CREATE  TRIGGER `t_insert_catalog_images` BEFORE INSERT ON `catalog_images`
 FOR EACH ROW BEGIN

 	UPDATE images set has_relation = 1 WHERE id = NEW.image_id;
  END
//
DELIMITER ;


-- TRIGGERS TABLE COMPANY_IMAGES

DROP TRIGGER IF EXISTS `t_delete_company_images`;
DELIMITER //
CREATE  TRIGGER `t_delete_company_images` AFTER DELETE ON `company_images`
 FOR EACH ROW BEGIN
 	IF NOT EXISTS(SELECT * FROM product_images WHERE image_id = OLD.image_id ) THEN
 		IF NOT EXISTS(SELECT * FROM catalog_images WHERE image_id = OLD.image_id ) THEN
		  UPDATE images set has_relation = 0 WHERE id = OLD.image_id;
	 	END IF;
 	END IF;		
  END
//
DELIMITER ;


DROP TRIGGER IF EXISTS `t_insert_company_images`;
DELIMITER //
CREATE  TRIGGER `t_insert_company_images` BEFORE INSERT ON `company_images`
 FOR EACH ROW BEGIN

 	UPDATE images set has_relation = 1 WHERE id = NEW.image_id;
  END
//
DELIMITER ;





