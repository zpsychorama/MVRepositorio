/*
 Navicat Premium Data Transfer

 Source Server         : pupo-test
 Source Server Type    : MariaDB
 Source Server Version : 100325
 Source Host           : ec2-54-233-180-102.sa-east-1.compute.amazonaws.com:3306
 Source Schema         : marketplace2

 Target Server Type    : MariaDB
 Target Server Version : 100325
 File Encoding         : 65001

 Date: 26/11/2020 23:33:16
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for applications
-- ----------------------------
DROP TABLE IF EXISTS `applications`;
CREATE TABLE `applications`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `primary_color` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `secondary_color` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `text_color` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  `main` tinyint(4) NOT NULL,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `idr` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of applications
-- ----------------------------
INSERT INTO `applications` VALUES (1, 'Pupo', '#ec5858', '#fd8c04', '#222831', 0, 1, '2020-11-26 15:59:11.696221', '2020-11-26 15:59:11.696221', 1);

-- ----------------------------
-- Table structure for catalog_images
-- ----------------------------
DROP TABLE IF EXISTS `catalog_images`;
CREATE TABLE `catalog_images`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `main` tinyint(4) NOT NULL,
  `idr` int(11) NOT NULL,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `catalog_id` bigint(20) NULL DEFAULT NULL,
  `image_id` bigint(20) NULL DEFAULT NULL,
  `image_type` enum('CATALOG','BANNER','UNKNOWN') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'UNKNOWN',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_dea189129729b96426cd9d57256`(`catalog_id`) USING BTREE,
  INDEX `FK_d5a99ff0b547bc61494efbc76b3`(`image_id`) USING BTREE,
  CONSTRAINT `FK_d5a99ff0b547bc61494efbc76b3` FOREIGN KEY (`image_id`) REFERENCES `images` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_dea189129729b96426cd9d57256` FOREIGN KEY (`catalog_id`) REFERENCES `catalogs` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of catalog_images
-- ----------------------------

-- ----------------------------
-- Table structure for catalogs
-- ----------------------------
DROP TABLE IF EXISTS `catalogs`;
CREATE TABLE `catalogs`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `unique_code` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `idr` int(11) NOT NULL,
  `city_id` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_8d642a737549b3a00f17ec25138`(`city_id`) USING BTREE,
  CONSTRAINT `FK_8d642a737549b3a00f17ec25138` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of catalogs
-- ----------------------------

-- ----------------------------
-- Table structure for cities
-- ----------------------------
DROP TABLE IF EXISTS `cities`;
CREATE TABLE `cities`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `minimun_order` decimal(22, 2) NOT NULL DEFAULT 0.00,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `idr` int(11) NOT NULL,
  `customer_departament_id` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_6b61debb051b9625448208d0183`(`customer_departament_id`) USING BTREE,
  CONSTRAINT `FK_6b61debb051b9625448208d0183` FOREIGN KEY (`customer_departament_id`) REFERENCES `customer_departments` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cities
-- ----------------------------

-- ----------------------------
-- Table structure for companies
-- ----------------------------
DROP TABLE IF EXISTS `companies`;
CREATE TABLE `companies`  (
  `idr` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `timezone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `logo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `banner` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `urlweb` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `accounting` tinyint(4) NOT NULL,
  `collection` tinyint(4) NOT NULL,
  `advances` tinyint(4) NOT NULL,
  `consignments` tinyint(4) NOT NULL,
  `messages` tinyint(4) NOT NULL,
  `customer_zone_type` int(2) NOT NULL,
  `price_list_type_id` int(2) NOT NULL,
  `visits` tinyint(4) NOT NULL,
  `transporters` tinyint(4) NOT NULL,
  `trans_assign` tinyint(4) NOT NULL,
  `promotions` tinyint(4) NOT NULL,
  `discount_rate` tinyint(4) NOT NULL,
  `saling_customers` tinyint(4) NOT NULL,
  `printer_customer` tinyint(4) NOT NULL,
  `printer_salesman` tinyint(4) NOT NULL,
  `vat_type_id` int(2) NOT NULL,
  `new_customer` tinyint(4) NOT NULL,
  `new_customer_photos` tinyint(4) NOT NULL,
  `pending_orders` tinyint(4) NOT NULL,
  `multi_cellars` tinyint(4) NOT NULL,
  `surveys` tinyint(4) NOT NULL,
  `sales` tinyint(4) NOT NULL,
  `promoters` tinyint(4) NOT NULL,
  `prom_distributors` tinyint(4) NOT NULL,
  `transporter_type` tinyint(4) NOT NULL,
  `customer_group` tinyint(4) NOT NULL,
  `potential` tinyint(4) NOT NULL,
  `customer_type` tinyint(4) NOT NULL,
  `customer_dispatch_day` tinyint(4) NOT NULL,
  `customer_geolocation` tinyint(4) NOT NULL,
  `simple_survey` tinyint(4) NOT NULL,
  `main_menu` tinyint(4) NOT NULL,
  `order_email` tinyint(4) NOT NULL,
  `order_email_total` tinyint(4) NOT NULL,
  `sales_stats` tinyint(4) NOT NULL,
  `newness_user` tinyint(4) NOT NULL,
  `delivery_date` tinyint(4) NOT NULL,
  `load_orders_to_deliveries` tinyint(4) NOT NULL,
  `web_track_precision` int(2) NOT NULL,
  `is_marketplace` tinyint(4) NOT NULL,
  PRIMARY KEY (`idr`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of companies
-- ----------------------------

-- ----------------------------
-- Table structure for company_images
-- ----------------------------
DROP TABLE IF EXISTS `company_images`;
CREATE TABLE `company_images`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `image_type` enum('COMPANY','BANNER','UNKNOWN') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'UNKNOWN',
  `main` tinyint(4) NOT NULL,
  `idr` int(11) NOT NULL,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `company_id` bigint(20) NULL DEFAULT NULL,
  `image_id` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_613066fdfd9b885b2344180d2e3`(`image_id`) USING BTREE,
  INDEX `FK_7af4cc08bb9fae1eb6417ac95c2`(`company_id`) USING BTREE,
  CONSTRAINT `FK_613066fdfd9b885b2344180d2e3` FOREIGN KEY (`image_id`) REFERENCES `images` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_7af4cc08bb9fae1eb6417ac95c2` FOREIGN KEY (`company_id`) REFERENCES `companies` (`idr`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of company_images
-- ----------------------------

-- ----------------------------
-- Table structure for countries
-- ----------------------------
DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of countries
-- ----------------------------

-- ----------------------------
-- Table structure for customer_addresses
-- ----------------------------
DROP TABLE IF EXISTS `customer_addresses`;
CREATE TABLE `customer_addresses`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `unique_code` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence` int(10) NULL DEFAULT NULL,
  `department` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `barrio` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `phone1` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `fax` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `email` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `pdv_alias` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `administrator_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `administrator_phone` bigint(20) NOT NULL,
  `administrator_birthdate` date NOT NULL,
  `business_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `owner_name` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `owner_phone` bigint(20) NULL DEFAULT NULL,
  `owner_birthdate` date NULL DEFAULT NULL,
  `cellar_meters` decimal(7, 2) NULL DEFAULT 0.00,
  `cellar_square_meters` decimal(7, 2) NULL DEFAULT 0.00,
  `anniversary_date` date NULL DEFAULT NULL,
  `payment_site_number` int(4) NULL DEFAULT NULL,
  `employees_number` int(4) NULL DEFAULT NULL,
  `alliances` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `others_alliances` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `gondolas_number` int(4) NULL DEFAULT NULL,
  `gondola_measure_high` decimal(7, 2) NULL DEFAULT 0.00,
  `gondola_measure_width` decimal(7, 2) NULL DEFAULT 0.00,
  `gondola_measure_depth` decimal(7, 2) NULL DEFAULT 0.00,
  `gondola_measure_shelf` decimal(7, 2) NULL DEFAULT 0.00,
  `edge_number` int(4) NULL DEFAULT NULL,
  `edge_measure_high` decimal(7, 2) NULL DEFAULT 0.00,
  `edge_measure_width` decimal(7, 2) NULL DEFAULT 0.00,
  `edge_measure_depth` decimal(7, 2) NULL DEFAULT 0.00,
  `edge_measure_shelf` decimal(7, 2) NULL DEFAULT 0.00,
  `pos` enum('YES','NO','UNKNOWN') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'UNKNOWN',
  `payment_metod` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `facade_image` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `monthly_hours` int(5) NOT NULL,
  `is_enable` tinyint(4) NOT NULL,
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `update_date` datetime(0) NULL DEFAULT NULL,
  `latitude` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `longitude` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `precision1` int(10) NULL DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL,
  `contacto_1` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `contacto_2` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `contacto_3` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `idr` int(11) NOT NULL,
  `customer_id` bigint(20) NULL DEFAULT NULL,
  `customer_group_id` bigint(20) NULL DEFAULT NULL,
  `customer_sub_group_id` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_6be4e1a698f5c3f2c2e4c75c186`(`customer_id`) USING BTREE,
  INDEX `FK_a1ed55527923806b5d7ad42009d`(`customer_group_id`) USING BTREE,
  INDEX `FK_dda36e5bd26788aa227118ed56a`(`customer_sub_group_id`) USING BTREE,
  CONSTRAINT `FK_6be4e1a698f5c3f2c2e4c75c186` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_a1ed55527923806b5d7ad42009d` FOREIGN KEY (`customer_group_id`) REFERENCES `groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_dda36e5bd26788aa227118ed56a` FOREIGN KEY (`customer_sub_group_id`) REFERENCES `sub_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customer_addresses
-- ----------------------------

-- ----------------------------
-- Table structure for customer_departments
-- ----------------------------
DROP TABLE IF EXISTS `customer_departments`;
CREATE TABLE `customer_departments`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `idr` int(11) NOT NULL,
  `created` timestamp(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `country_id` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_6f8a23bd3d1b3c354c1098974f4`(`country_id`) USING BTREE,
  CONSTRAINT `FK_6f8a23bd3d1b3c354c1098974f4` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customer_departments
-- ----------------------------

-- ----------------------------
-- Table structure for customers
-- ----------------------------
DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `unique_code` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `token` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `identification_type_id` int(10) NOT NULL,
  `identification` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `password` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `customer_potential_id` bigint(20) NULL DEFAULT NULL,
  `buy_contact` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `customer_type_id` int(20) NULL DEFAULT NULL,
  `city_code` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `quota` decimal(28, 3) NOT NULL,
  `credit` decimal(13, 2) NOT NULL,
  `dispatch_day` varchar(70) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `distributors` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `department` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL,
  `api_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `last_sync` datetime(0) NULL DEFAULT NULL,
  `image_type` enum('S','N','E') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'S',
  `sinc_response` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `payment_conditions` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `image` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `logo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `idr` int(11) NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customers
-- ----------------------------

-- ----------------------------
-- Table structure for delivery_order_details
-- ----------------------------
DROP TABLE IF EXISTS `delivery_order_details`;
CREATE TABLE `delivery_order_details`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `invoice` char(22) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `line_seq_num` int(5) NOT NULL,
  `product_reference` char(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `total_sale` decimal(22, 2) NOT NULL DEFAULT 0.00,
  `measurement_unit_1_id` char(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `cant_1` int(11) NOT NULL,
  `measurement_unit_2_id` char(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `cant_2` int(11) NOT NULL,
  `measurement_unit_3_id` char(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `cant_3` int(6) NOT NULL,
  `measurement_unit_4_id` char(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `cant_4` int(11) NOT NULL,
  `comment` char(254) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `impuestos` decimal(10, 2) NOT NULL DEFAULT 0.00,
  `status` enum('D','N','UNKNOWN') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'UNKNOWN',
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `idr` int(11) NOT NULL,
  `delivery_order_id` bigint(20) NULL DEFAULT NULL,
  `product_id` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_95257be11de5bcebaa082c1a4cf`(`delivery_order_id`) USING BTREE,
  INDEX `FK_dce5c9299f5b9fbf9f17e0aa5dc`(`product_id`) USING BTREE,
  CONSTRAINT `FK_95257be11de5bcebaa082c1a4cf` FOREIGN KEY (`delivery_order_id`) REFERENCES `delivery_orders` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_dce5c9299f5b9fbf9f17e0aa5dc` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of delivery_order_details
-- ----------------------------

-- ----------------------------
-- Table structure for delivery_orders
-- ----------------------------
DROP TABLE IF EXISTS `delivery_orders`;
CREATE TABLE `delivery_orders`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ship_id` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `invoice` char(22) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `address_seq_num` int(3) NOT NULL,
  `carrier_id` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `zone_name` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `total_units` int(11) NOT NULL,
  `output_date` date NOT NULL,
  `ruta` char(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `comment` char(254) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `flag` enum('E','N','P','D','A','PA','PAP','AP','FPPA','FPA','ASN') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'N',
  `business_unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `business_unit_bi` char(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `internal_invoice` char(22) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `total_invoice` int(22) NOT NULL,
  `invoice_date` date NULL DEFAULT NULL,
  `pymnt_terms_cd` char(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `due_date` date NULL DEFAULT NULL,
  `business_unit_ar` char(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `payment_method_id` bigint(20) NOT NULL,
  `pedido` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `total_bruto` int(25) NULL DEFAULT NULL,
  `status` enum('S','N') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'N',
  `salesman` char(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `zona` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `jornada` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `order_date` date NULL DEFAULT NULL,
  `sincronizado` enum('S','N') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'N',
  `typeLoad` enum('DL','DLL','UNKNOWN') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'UNKNOWN',
  `status_efectivo` int(11) NOT NULL DEFAULT 1,
  `idr` int(11) NOT NULL,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `customer_id` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_a303f80865f095605a2dd2085e9`(`customer_id`) USING BTREE,
  CONSTRAINT `FK_a303f80865f095605a2dd2085e9` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of delivery_orders
-- ----------------------------

-- ----------------------------
-- Table structure for groups
-- ----------------------------
DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `unique_code` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `group` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `idr` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of groups
-- ----------------------------

-- ----------------------------
-- Table structure for images
-- ----------------------------
DROP TABLE IF EXISTS `images`;
CREATE TABLE `images`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `size` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  `has_relation` tinyint(4) NOT NULL,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `application_id` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_9326b8ea32abed0dd9ec4ab2d07`(`application_id`) USING BTREE,
  CONSTRAINT `FK_9326b8ea32abed0dd9ec4ab2d07` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of images
-- ----------------------------

-- ----------------------------
-- Table structure for product_images
-- ----------------------------
DROP TABLE IF EXISTS `product_images`;
CREATE TABLE `product_images`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `image_type` enum('PRODUCT','BANNER','UNKNOWN') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'UNKNOWN',
  `main` tinyint(4) NOT NULL,
  `idr` int(11) NOT NULL,
  `created` datetime(6) NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `product_id` bigint(20) NULL DEFAULT NULL,
  `image_id` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_4f166bb8c2bfcef2498d97b4068`(`product_id`) USING BTREE,
  INDEX `FK_2212515ba306c79f42c46a99db7`(`image_id`) USING BTREE,
  CONSTRAINT `FK_2212515ba306c79f42c46a99db7` FOREIGN KEY (`image_id`) REFERENCES `images` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_4f166bb8c2bfcef2498d97b4068` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of product_images
-- ----------------------------

-- ----------------------------
-- Table structure for product_prices
-- ----------------------------
DROP TABLE IF EXISTS `product_prices`;
CREATE TABLE `product_prices`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `unique_code` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `product_reference` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `measure_unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price` decimal(17, 2) NULL DEFAULT 0.00,
  `discount` decimal(4, 2) NOT NULL DEFAULT 0.00,
  `commercial_discount` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `cash_discount` decimal(4, 2) NULL DEFAULT 0.00,
  `amount_units` int(10) NULL DEFAULT NULL,
  `vlr_impu_consumo` decimal(19, 4) NULL DEFAULT 0.0000,
  `impuest_consumo` int(11) NULL DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `idr` int(11) NOT NULL,
  `cash_discount_min` decimal(4, 2) NULL DEFAULT 0.00,
  `cash_discount_due_date` datetime(0) NULL DEFAULT NULL,
  `price_min` decimal(17, 2) NULL DEFAULT 0.00,
  `price_max` decimal(17, 2) NULL DEFAULT 0.00,
  `price_due_date` datetime(0) NULL DEFAULT NULL,
  `product_id` bigint(20) NULL DEFAULT NULL,
  `catalog_id` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_8218c69c7f5a3706662101fa788`(`product_id`) USING BTREE,
  INDEX `FK_328c1f9349281b2e375ebe88860`(`catalog_id`) USING BTREE,
  CONSTRAINT `FK_328c1f9349281b2e375ebe88860` FOREIGN KEY (`catalog_id`) REFERENCES `catalogs` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_8218c69c7f5a3706662101fa788` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of product_prices
-- ----------------------------

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `reference` char(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `grammage` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `competition_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `competition_grammage` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `packing` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `stock` bigint(20) NOT NULL,
  `weight` decimal(14, 3) NULL DEFAULT 0.000,
  `volume` decimal(14, 3) NULL DEFAULT 0.000,
  `brand` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `convertion_rate` decimal(10, 7) NULL DEFAULT 0.0000000,
  `vat_group` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `vat` decimal(4, 2) NOT NULL DEFAULT 0.00,
  `packing_to` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL,
  `ranking` int(11) NOT NULL,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `idr` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of products
-- ----------------------------

-- ----------------------------
-- Table structure for sub_groups
-- ----------------------------
DROP TABLE IF EXISTS `sub_groups`;
CREATE TABLE `sub_groups`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `unique_code` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sub_group` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  `created` datetime(6) NOT NULL DEFAULT current_timestamp,
  `modified` timestamp(6) NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `idr` int(11) NOT NULL,
  `group_id` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_3ac2eb2ba46f9c53fadd6fb7eb1`(`group_id`) USING BTREE,
  CONSTRAINT `FK_3ac2eb2ba46f9c53fadd6fb7eb1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sub_groups
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 1;
